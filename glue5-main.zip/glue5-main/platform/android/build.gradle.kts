// The Android app: a thin package around the glue5 library (the same crate
// as the desktop and iOS apps) and SDL's Java side. `mise run android` /
// `android:build` build the libraries and the icon's drawables into
// target/android, then run this with glue5.sdlJava: SDL's Java sources, from
// the sdl3-src crate the libraries were built with. Gradle's output goes to
// target/android/gradle.

plugins {
    id("com.android.application") version "9.4.1"
}

val repo = rootDir.resolve("../..")
val generated = repo.resolve("target/android")
fun setting(name: String): String = providers.gradleProperty("glue5.$name").get()

layout.buildDirectory = generated.resolve("gradle")

android {
    namespace = "local.glue5"
    compileSdk = setting("compileSdk").toInt()
    buildToolsVersion = setting("buildTools")
    // For stripping the libraries' debug information.
    ndkVersion = setting("ndk")

    defaultConfig {
        applicationId = "local.glue5"
        minSdk = setting("minSdk").toInt()
        targetSdk = setting("compileSdk").toInt()
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release {
            // For development devices, as the iOS app: the debug key.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    sourceSets["main"].apply {
        manifest.srcFile("AndroidManifest.xml")
        java.srcDirs("java", setting("sdlJava"))
        res.srcDirs("res", generated.resolve("res"))
        jniLibs.srcDirs(generated.resolve("jniLibs"))
    }

    lint {
        // Not on every release build (it is slow): `gradle lint` by hand.
        checkReleaseBuilds = false
    }
}
