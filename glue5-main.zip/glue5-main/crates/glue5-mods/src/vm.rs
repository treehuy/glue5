//! A mod's Luau VM: sandboxed, with the natives as namespace tables, `wait`
//! and `require` (the mod's own files); its main chunk runs as a coroutine
//! the engine resumes once per wait. The REPL's VM (`eval`) is the same
//! with a loop that runs the snippets it is given.

use std::cell::{Cell, RefCell};
use std::collections::{HashMap, VecDeque};
use std::path::{Path, PathBuf};
use std::rc::Rc;
use std::sync::mpsc::Sender;
use std::time::{Duration, Instant};

use mlua::{Function, Lua, LuaOptions, MultiValue, StdLib, Table, Thread, Value, VmState};

use crate::world::Pool;
use crate::storage::Storage;
use crate::{EvalResult, json, menus, natives};

/// How long a mod may run before it yields to the game for this frame.
pub const SLICE: Duration = Duration::from_millis(2);
/// How long a mod may run without calling `wait` before it is stopped.
const RUNAWAY: Duration = Duration::from_secs(2);
/// Memory a mod's VM may use.
const MEMORY: usize = 64 << 20;

/// Snippets for the REPL: code, and where its result goes.
pub type Jobs = Rc<RefCell<VecDeque<(String, Sender<EvalResult>)>>>;

pub struct Vm {
    lua: Lua,
    module: String,
    /// The main chunk, until it ends, and when it is due (game time, ms).
    main: Option<Thread>,
    main_wake: u64,
    main_busy: Duration,
    /// Tasks: `task.spawn`/`task.delay`, menus' callbacks.
    sched: Sched,
    deadline: Rc<Cell<Instant>>,
    /// When this turn's time is up (all its coroutines share it).
    turn_end: Cell<Instant>,
    /// Which goes first this turn, the main chunk or the tasks (they take
    /// turns, so neither starves the other).
    main_first: Cell<bool>,
    /// The mod's `storage` (none for the REPL).
    storage: Option<Rc<Storage>>,
}

/// What `task.*` and the menus share with the VM.
#[derive(Clone, Default)]
struct Sched {
    tasks: Rc<RefCell<Vec<Task>>>,
    /// The game time of the current turn, ms.
    now: Rc<Cell<u64>>,
    handlers: menus::Handlers,
    /// This run of the mod (its menus are its own).
    instance: u64,
    /// The coroutine the scheduler is running (`Thread::to_pointer`).
    resumed: Rc<Cell<*const std::ffi::c_void>>,
}

struct Task {
    thread: Thread,
    wake: u64,
    /// What it starts with (a callback's arguments), the first time.
    args: Option<MultiValue>,
    busy: Duration,
}

/// What a turn of a mod came to.
pub enum Step {
    /// The next thing it does is this many milliseconds away (0: the next
    /// frame).
    Wait(u32),
    Finished,
    Failed(String),
}

/// What a coroutine's run came to.
enum Outcome {
    Wait(u32),
    Preempted,
    Finished,
    Failed(String),
}

impl Vm {
    /// Loads mod `name`'s `main.luau` from `dir`; `log` gets what it prints.
    pub fn new(name: &str, dir: &Path, log: Rc<dyn Fn(&str)>) -> mlua::Result<Vm> {
        let sched = Sched { instance: menus::next_instance(), ..Sched::default() };
        let (lua, deadline) = base(name, log, &sched)?;
        lua.globals().set("require", require(&lua, name, dir)?)?;
        let storage = Storage::open(name);
        storage.install(&lua)?;
        // The mod's code starts once the player is in the game (not on
        // the loading screens, where the player's ped is a stand-in).
        let ready: Function = lua
            .load(
                "local yield = coroutine.yield\n\
                 return function(main) return function(...)\n\
                 while dlc.getIsLoadingScreenActive() or not camera.isScreenFadedIn() \
                 or not player.isPlayerPlaying(player.playerId()) do yield(0) end\n\
                 return main(...)\n\
                 end end",
            )
            .set_name("=ready")
            .eval()?;
        lua.sandbox(true)?;
        let path = dir.join("main.luau");
        let source = std::fs::read_to_string(&path)
            .map_err(|e| mlua::Error::runtime(format!("reading {}: {e}", path.display())))?;
        let chunk = lua.load(source).set_name(format!("@{name}/main.luau")).into_function()?;
        let main = lua.create_thread(ready.call::<Function>(chunk)?)?;
        Ok(Vm {
            lua,
            module: name.to_string(),
            main: Some(main),
            main_wake: 0,
            main_busy: Duration::ZERO,
            sched,
            deadline,
            turn_end: Cell::new(Instant::now()),
            main_first: Cell::new(false),
            storage: Some(storage),
        })
    }

    /// The REPL: runs `jobs`' snippets, as expressions when they are.
    pub fn repl(jobs: Jobs, log: Rc<dyn Fn(&str)>) -> mlua::Result<Vm> {
        let sched = Sched { instance: menus::next_instance(), ..Sched::default() };
        let (lua, deadline) = base("eval", log, &sched)?;
        let waiting: Rc<RefCell<HashMap<i64, Sender<EvalResult>>>> = Rc::default();
        let next = Cell::new(0i64);
        let pending = waiting.clone();
        let take = lua.create_function(move |lua, ()| {
            let Some((code, reply)) = jobs.borrow_mut().pop_front() else { return Ok(MultiValue::new()) };
            let id = next.get() + 1;
            next.set(id);
            let compiled = lua
                .load(format!("return {code}"))
                .set_name("=eval")
                .into_function()
                .or_else(|_| lua.load(code.as_str()).set_name("=eval").into_function());
            Ok(match compiled {
                Ok(f) => {
                    pending.borrow_mut().insert(id, reply);
                    MultiValue::from_vec(vec![Value::Integer(id), Value::Function(f)])
                }
                Err(e) => {
                    let _ = reply.send(Err(error_text(&e)));
                    MultiValue::new()
                }
            })
        })?;
        let reply = lua.create_function(move |_, args: MultiValue| {
            let mut args = args.into_iter();
            let id = match args.next() {
                Some(Value::Integer(id)) => id,
                _ => return Ok(()),
            };
            let ok = matches!(args.next(), Some(Value::Boolean(true)));
            let values: Vec<Value> = args.collect();
            if let Some(sender) = waiting.borrow_mut().remove(&id) {
                let _ = sender.send(if ok {
                    Ok(values.iter().map(describe).collect::<Vec<_>>().join(", "))
                } else {
                    Err(values.first().map_or_else(|| "error".into(), describe_plain))
                });
            }
            Ok(())
        })?;
        let main: Function = lua
            .load(
                "local take, reply = ...\n\
                 return function()\n\
                 while true do\n\
                 local id, f = take()\n\
                 if id then reply(id, pcall(f)) else wait() end\n\
                 end end",
            )
            .set_name("=repl")
            .call((take, reply))?;
        lua.sandbox(true)?;
        let main = lua.create_thread(main)?;
        Ok(Vm { lua, module: "eval".into(), main: Some(main), main_wake: 0, main_busy: Duration::ZERO, sched, deadline, turn_end: Cell::new(Instant::now()), main_first: Cell::new(false), storage: None })
    }

    /// A turn at game time `now` (ms): what the player did with the menus
    /// becomes tasks; the tasks and the main chunk that are due run, until
    /// they wait, end, fail or run out of time.
    pub fn step(&mut self, now: u64, slice: Duration) -> Step {
        self.sched.now.set(now);
        self.turn_end.set(Instant::now() + slice.min(SLICE));
        self.main_first.set(!self.main_first.get());
        if let Some(storage) = &self.storage {
            storage.flush(false);
        }
        for (item, input) in menus::take_inputs(&self.module) {
            match menus::apply(&self.lua, &self.sched.handlers, item, input) {
                Ok(Some((f, args))) => match self.lua.create_thread(f) {
                    Ok(thread) => self.sched.tasks.borrow_mut().push(Task { thread, wake: now, args: Some(args), busy: Duration::ZERO }),
                    Err(e) => crate::log_line(&self.module, crate::LogLevel::Error, &error_text(&e)),
                },
                Ok(None) => {}
                Err(e) => crate::log_line(&self.module, crate::LogLevel::Error, &error_text(&e)),
            }
        }
        if self.main_first.get() {
            if let Some(failed) = self.run_main(now) {
                return failed;
            }
            self.run_tasks(now);
        } else {
            self.run_tasks(now);
            if let Some(failed) = self.run_main(now) {
                return failed;
            }
        }
        let menus = menus::has_menus(self.sched.instance);
        let tasks = self.sched.tasks.borrow();
        if self.main.is_none() && tasks.is_empty() && !menus {
            return Step::Finished;
        }
        // A menu may be used any time: every frame then.
        if menus {
            return Step::Wait(0);
        }
        let next = tasks.iter().map(|t| t.wake).chain(self.main.as_ref().map(|_| self.main_wake)).min().unwrap_or(now);
        Step::Wait(next.saturating_sub(now).min(u64::from(u32::MAX)) as u32)
    }

    /// The tasks that are due, while the turn lasts.
    fn run_tasks(&mut self, now: u64) {
        // The tasks that are due; others may be added while they run.
        let due: Vec<Task> = {
            let mut tasks = self.sched.tasks.borrow_mut();
            let (due, later): (Vec<Task>, Vec<Task>) = tasks.drain(..).partition(|t| t.wake <= now);
            *tasks = later;
            due
        };
        for mut task in due {
            // Out of time this turn: next turn, as it was.
            if Instant::now() >= self.turn_end.get() {
                self.sched.tasks.borrow_mut().push(task);
                continue;
            }
            let args = task.args.take().unwrap_or_default();
            let (outcome, spent) = self.run(&task.thread, args);
            task.busy += spent;
            match outcome {
                Outcome::Wait(ms) => {
                    task.wake = now + u64::from(ms);
                    task.busy = Duration::ZERO;
                }
                Outcome::Preempted if task.busy >= RUNAWAY => {
                    crate::log_line(&self.module, crate::LogLevel::Error, &runaway());
                    continue;
                }
                Outcome::Preempted => task.wake = now,
                Outcome::Finished => continue,
                Outcome::Failed(e) => {
                    // A task's error is logged; the mod goes on.
                    crate::log_line(&self.module, crate::LogLevel::Error, &e);
                    continue;
                }
            }
            self.sched.tasks.borrow_mut().push(task);
        }
    }

    /// The main chunk, if due and the turn lasts; a failure ends the mod.
    fn run_main(&mut self, now: u64) -> Option<Step> {
        if let Some(main) = self.main.clone()
            && self.main_wake <= now
            && Instant::now() < self.turn_end.get()
        {
            let (outcome, spent) = self.run(&main, MultiValue::new());
            self.main_busy += spent;
            match outcome {
                Outcome::Wait(ms) => {
                    self.main_wake = now + u64::from(ms);
                    self.main_busy = Duration::ZERO;
                }
                Outcome::Preempted if self.main_busy >= RUNAWAY => return Some(Step::Failed(runaway())),
                Outcome::Preempted => self.main_wake = now,
                Outcome::Finished => self.main = None,
                Outcome::Failed(e) => return Some(Step::Failed(e)),
            }
        }
        None
    }

    /// Runs a coroutine until it yields, ends or fails; and how long it ran.
    fn run(&self, thread: &Thread, args: MultiValue) -> (Outcome, Duration) {
        if !thread.is_resumable() {
            return (Outcome::Finished, Duration::ZERO);
        }
        let start = Instant::now();
        self.deadline.set(self.turn_end.get());
        self.sched.resumed.set(thread.to_pointer());
        let result = thread.resume::<MultiValue>(args);
        let spent = start.elapsed();
        let outcome = match result {
            Err(e) => Outcome::Failed(error_text(&e)),
            Ok(_) if !thread.is_resumable() => Outcome::Finished,
            // `wait(ms)`.
            Ok(values) => match values.into_iter().next() {
                Some(v) => Outcome::Wait(match v {
                    Value::Integer(i) => i.clamp(0, i32::MAX.into()) as u32,
                    Value::Number(n) if n.is_finite() => n.clamp(0.0, i32::MAX as f64) as u32,
                    _ => 0,
                }),
                // The interrupt: out of time.
                None => Outcome::Preempted,
            },
        };
        (outcome, spent)
    }

    /// Memory the VM uses, in bytes.
    pub fn memory(&self) -> usize {
        self.lua.used_memory()
    }
}

fn runaway() -> String {
    format!("ran for {} s without calling wait(): a loop needs wait() to let the game go on", RUNAWAY.as_secs())
}

/// A VM with the libraries, the natives and the mods' globals (`print`,
/// `wait`, `task`, `ui`, `joaat`, `mod`), and the interrupt that keeps a
/// slice short; not sandboxed yet.
fn base(name: &str, log: Rc<dyn Fn(&str)>, sched: &Sched) -> mlua::Result<(Lua, Rc<Cell<Instant>>)> {
    let lua = Lua::new_with(
        StdLib::COROUTINE
            | StdLib::TABLE
            | StdLib::STRING
            | StdLib::UTF8
            | StdLib::MATH
            | StdLib::BIT
            | StdLib::VECTOR
            | StdLib::BUFFER
            | StdLib::OS,
        LuaOptions::default(),
    )?;
    lua.set_memory_limit(MEMORY)?;
    let g = lua.globals();
    g.set(
        "print",
        lua.create_function(move |_, args: MultiValue| {
            let line = args.iter().map(describe_plain).collect::<Vec<_>>().join(" ");
            log(&line);
            Ok(())
        })?,
    )?;
    // `wait(ms)`: back to the game until then; plain Lua, so it yields from
    // the running coroutine.
    let wait: Function = lua
        .load("local yield = coroutine.yield\nreturn function(ms) yield(ms or 0) end")
        .set_name("=wait")
        .eval()?;
    g.set("wait", wait.clone())?;
    // `task.spawn(f, ...)`, `task.delay(ms, f, ...)`, `task.wait(ms)`.
    let task = lua.create_table()?;
    task.set("wait", wait)?;
    let s = sched.clone();
    task.set(
        "spawn",
        lua.create_function(move |lua, (f, args): (Function, MultiValue)| {
            let thread = lua.create_thread(f)?;
            s.tasks.borrow_mut().push(Task { thread, wake: s.now.get(), args: Some(args), busy: Duration::ZERO });
            Ok(())
        })?,
    )?;
    let s = sched.clone();
    task.set(
        "delay",
        lua.create_function(move |lua, (ms, f, args): (f64, Function, MultiValue)| {
            let thread = lua.create_thread(f)?;
            let wake = s.now.get() + ms.clamp(0.0, 1e9) as u64;
            s.tasks.borrow_mut().push(Task { thread, wake, args: Some(args), busy: Duration::ZERO });
            Ok(())
        })?,
    )?;
    menus::install(&lua, name, sched.instance, sched.handlers.clone())?;
    json::install(&lua)?;
    // `world.vehicles()`..., the catalog's lists.
    let world = lua.create_table()?;
    for (key, pool) in [("vehicles", Pool::Vehicles), ("peds", Pool::Peds), ("objects", Pool::Objects)] {
        world.set(
            key,
            lua.create_function(move |_, max: Option<usize>| {
                let env = natives::env().ok_or_else(|| mlua::Error::runtime(format!("world.{key}: only in a mod's script")))?;
                Ok(unsafe { crate::world::handles(env, pool, max.unwrap_or(1024).min(4096)) })
            })?,
        )?;
    }
    world.set("vehicleModels", lua.create_function(|_, ()| Ok(crate::world::catalog().map(|c| c.vehicles).unwrap_or_default()))?)?;
    world.set("pedModels", lua.create_function(|_, ()| Ok(crate::world::catalog().map(|c| c.peds).unwrap_or_default()))?)?;
    world.set("weapons", lua.create_function(|_, ()| Ok(crate::world::catalog().map(|c| c.weapons).unwrap_or_default()))?)?;
    g.set("world", world)?;
    g.set("joaat", lua.create_function(|_, s: mlua::LuaString| Ok(natives::joaat(&s.to_str()?)))?)?;
    let m = lua.create_table()?;
    m.set("name", name)?;
    g.set("mod", m)?;

    // A table per namespace; a native's function is made the first time it
    // is looked up.
    for (ns, space) in natives::NAMESPACES.iter().enumerate() {
        let cache: RefCell<HashMap<String, Function>> = RefCell::default();
        let table = lua.create_table()?;
        let meta = lua.create_table()?;
        meta.set(
            "__index",
            lua.create_function(move |lua, (_, key): (Table, String)| {
                if let Some(f) = cache.borrow().get(&key) {
                    return Ok(Value::Function(f.clone()));
                }
                let Some(index) = natives::find(ns, &key) else { return Ok(Value::Nil) };
                let f = lua.create_function(move |lua, args: MultiValue| natives::call(lua, index, args))?;
                cache.borrow_mut().insert(key, f.clone());
                Ok(Value::Function(f))
            })?,
        )?;
        table.set_metatable(Some(meta))?;
        if *space == "task" {
            // The scheduler shares the table with the TASK_ natives.
            for pair in task.pairs::<Value, Value>() {
                let (k, v) = pair?;
                table.raw_set(k, v)?;
            }
        }
        g.set(*space, table)?;
    }

    let deadline = Rc::new(Cell::new(Instant::now() + SLICE));
    let interrupt_deadline = deadline.clone();
    let resumed = sched.resumed.clone();
    lua.set_interrupt(move |lua| {
        let late = Instant::now().saturating_duration_since(interrupt_deadline.get());
        if late.is_zero() {
            return Ok(VmState::Continue);
        }
        // Past the runaway limit whatever runs: a yield where Luau cannot
        // (a metamethod, a sort's comparator, a module `require` runs) is
        // dropped, so a loop there would never give the game back.
        if late >= RUNAWAY {
            return Err(mlua::Error::runtime(runaway()));
        }
        // Only the coroutine the scheduler resumed yields back to it; one
        // the mod made itself (coroutine.wrap) would hand its resume an
        // empty result. That one runs on, up to the runaway limit.
        if lua.current_thread().to_pointer() == resumed.get() { Ok(VmState::Yield) } else { Ok(VmState::Continue) }
    });
    Ok((lua, deadline))
}

/// `require("./menu")`: the mod's `menu.luau`, run once.
fn require(lua: &Lua, name: &str, dir: &Path) -> mlua::Result<Function> {
    let loaded: RefCell<HashMap<PathBuf, Value>> = RefCell::default();
    let (name, dir) = (name.to_string(), dir.to_path_buf());
    lua.create_function(move |lua, path: String| {
        let rel = path
            .strip_prefix("./")
            .filter(|r| !r.split('/').any(|p| p.is_empty() || p.starts_with('.')))
            .ok_or_else(|| mlua::Error::runtime(format!("require(\"{path}\"): a file of the mod, as \"./name\"")))?;
        let file = dir.join(format!("{rel}.luau"));
        if let Some(v) = loaded.borrow().get(&file) {
            return Ok(v.clone());
        }
        let source = std::fs::read_to_string(&file)
            .map_err(|e| mlua::Error::runtime(format!("require(\"{path}\"): {e}")))?;
        let value: Value = lua.load(source).set_name(format!("@{name}/{rel}.luau")).call(())?;
        let value = if value.is_nil() { Value::Boolean(true) } else { value };
        loaded.borrow_mut().insert(file, value.clone());
        Ok(value)
    })
}

/// An error as people read it: its message, and where in the mod's files it
/// happened when the message does not say (natives' errors).
pub fn error_text(e: &mlua::Error) -> String {
    let (message, traceback) = match e {
        mlua::Error::CallbackError { traceback, cause } => (error_text(cause), Some(traceback.as_str())),
        // Without the traceback the message carries (its `file:line` is enough).
        mlua::Error::RuntimeError(m) => (m.split("\nstack traceback:").next().unwrap_or(m).to_string(), None),
        mlua::Error::SyntaxError { message, .. } => (message.clone(), None),
        mlua::Error::MemoryError(_) => ("out of memory (a mod may use 64 MB)".into(), None),
        other => (other.to_string(), None),
    };
    // `trainer/main.luau:12: in function ...`: the first frame in a mod's file.
    let at = traceback.and_then(|t| {
        t.lines().map(str::trim).find(|l| l.contains(".luau:")).and_then(|l| {
            let end = l.find(".luau:")? + 6;
            let digits = l[end..].chars().take_while(char::is_ascii_digit).count();
            Some(l[..end + digits].trim_start_matches('@').to_string())
        })
    });
    match at {
        Some(at) if !message.contains(".luau:") => format!("{at}: {message}"),
        _ => message,
    }
}

/// A value as the REPL shows it.
pub fn describe(v: &Value) -> String {
    match v {
        Value::String(s) => format!("{:?}", s.to_string_lossy()),
        other => describe_plain(other),
    }
}

/// A value as `print` shows it: strings as they are.
fn describe_plain(v: &Value) -> String {
    match v {
        Value::Nil => "nil".into(),
        Value::Boolean(b) => b.to_string(),
        Value::Integer(i) => i.to_string(),
        Value::Number(n) if n.fract() == 0.0 && n.abs() < 1e15 => format!("{n:.0}"),
        Value::Number(n) => format!("{n}"),
        Value::Vector(v) => format!("vector({}, {}, {})", short(v.x()), short(v.y()), short(v.z())),
        Value::String(s) => s.to_string_lossy(),
        Value::Table(t) => {
            let mut parts = Vec::new();
            for (i, pair) in t.pairs::<Value, Value>().enumerate() {
                if i == 16 {
                    parts.push("…".to_string());
                    break;
                }
                if let Ok((k, v)) = pair {
                    parts.push(match k {
                        Value::Integer(_) => describe(&v),
                        k => format!("{} = {}", describe_plain(&k), describe(&v)),
                    });
                }
            }
            format!("{{{}}}", parts.join(", "))
        }
        Value::Function(_) => "function".into(),
        Value::Error(e) => error_text(e),
        other => other.type_name().into(),
    }
}

fn short(x: f32) -> String {
    let s = format!("{x:.2}");
    s.trim_end_matches('0').trim_end_matches('.').to_string()
}

impl Vm {
    /// This run of the mod.
    pub fn instance(&self) -> u64 {
        self.sched.instance
    }

    /// Writes what the mod stored, now.
    pub fn flush_storage(&self) {
        if let Some(storage) = &self.storage {
            storage.flush(true);
        }
    }

    /// Writes what the mod stored when it is time (every couple of
    /// seconds), also while it waits long between its turns.
    pub fn flush_storage_due(&self) {
        if let Some(storage) = &self.storage {
            storage.flush(false);
        }
    }

    /// Empties the mod's storage.
    pub fn clear_storage(&self) {
        if let Some(storage) = &self.storage {
            storage.clear_now();
        }
    }
}

impl Drop for Vm {
    /// The mod stops: its storage is written now.
    fn drop(&mut self) {
        if let Some(storage) = &self.storage {
            storage.flush(true);
        }
    }
}
